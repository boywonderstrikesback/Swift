import Cocoa


class MyClass {
    var instanceName = "New Instance"
    
}

var instance  = MyClass()
var instance2 = MyClass()
var instance3 = MyClass()
var instance4 = MyClass()


instance2.instanceName = "instance 2"
instance3.instanceName = "instance 3"
instance4.instanceName = "instance 4"


let myArray = [instance]
var myArray10: [MyClass] = [instance]
var myArray11: Array<MyClass> = [instance2]

myArray10 += [instance3]
myArray11 += [instance4]


myArray.count
myArray10.count
myArray11.count
myArray11 [0] = instance3
myArray11.count

var subArray = myArray11 [0...1]
subArray.count

myArray11 = [instance,instance2,instance3, instance4]
myArray11.count

myArray11 [1...2] = [instance3,instance4]
myArray11.count


myArray11[0...3] = [instance3, instance4]
myArray11.count
