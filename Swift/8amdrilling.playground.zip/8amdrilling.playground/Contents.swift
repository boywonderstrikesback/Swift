import UIKit

var str = "Hello,playground"




let str1 = "hello"
let str2 = "world"
let str3 = str1 + " " + str2

var testOverflow = UInt16.max
testOverflow = testOverflow &+ 1


var testDivision = 5 / 0.5


var test = Int16.max
var test2 = test-1000
var test3 = test2&*2



var itemCount: Float = 17
var itemsPerPage: Float = 5


var pageCount:Float  = ceil(Float(itemCount / itemsPerPage))
var leftOvers = itemCount / itemsPerPage


var totalPages = pageCount + (leftOvers > 0 ? 1:0 )


var a:Float = 2
a*=21.63


var h1: NSString = "Hello"
var h2: NSString = "Hello"

var b = h1 == h2
b = h1 === h2

var b3 = 3
var b4 = 4

var bTest = b3 <= b4

print (b4)

var s = b4.description

var i : Float = 17
    i = 25.0



    i = i * 2




var myTuple = (anInt:5 , aFloat: 103, aBool: true)


myTuple.anInt
myTuple.aFloat
myTuple.aBool



myTuple.0
myTuple.1
myTuple.2


let (myDecompose1, myDecompose2, myDecompose3) = myTuple
myDecompose1
myDecompose2
myDecompose3

let(_, myDecompose,_) = myTuple

myDecompose

var myTuple2 =
    (anInt: Int(), aFloat: Float(), aBool: Bool() )
print (myTuple2)

myTuple = (99, 99, false)

















