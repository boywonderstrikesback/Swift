import Cocoa

var str = "Hello, playground"



var elements = [1,3,5,17,-1]
var index = 0


var myElementCounter = 0;


for myElement in elements {

    if myElement < 0 {
    print ( " \(myElement.description) at \(index.description) is a negative number")
    }
 
    index+=1

}


var anArray = Array<Int>()
var i = 0; i < 10; i+=1; do {
    // Generate random number in range 0 <= randomNumber < 100
    let randomNumber = Int(arc4random() % 100)
    anArray.append(randomNumber)
}
// Note: Your output will undoubtedly be different to the this
// [14, 38, 14, 3, 55]
