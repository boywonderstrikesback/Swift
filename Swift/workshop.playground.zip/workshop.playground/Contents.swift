//: A UIKit based Playground for presenting user interface
  
import UIKit




var str = String(1)
var str2: Int = 1

var j = 0

for i in 0..<200{
    j = i * 4
    
}





